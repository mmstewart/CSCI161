package lab002;

/**
 *
 * @author Marcus
 */
public class TestScoresClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        
    }
    
}
